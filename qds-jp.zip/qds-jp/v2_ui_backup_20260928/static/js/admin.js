let currentThreat = 'authentic';
const seenTx = new Set();

document.addEventListener('DOMContentLoaded', () => {
  connectSocket('admin', handleMessage, online => {
    setConnectionBadge(online, 'ONLINE');
    if (online) logTerminal('SYS', 'Authenticated WebSocket connected.');
  });
  initThreatCards();
  initComposer();
  document.getElementById('btnResetLinks').addEventListener('click', resetLinks);
  document.getElementById('btnCheckChain').addEventListener('click', checkChain);
  loadHistory();
  refreshMetrics();
  refreshTopology();
  loadIncidents();
});

function handleMessage(msg) {
  if (msg.event === 'init_sync') {
    if (msg.data.stats) updateStatsDisplay(msg.data.stats);
    if (msg.data.active_threat) setArmedThreatUI(msg.data.active_threat);
    renderLinks(msg.data.channel_state);
  } else if (msg.event === 'new_transmission') {
    handleNewTransmission(msg.data.transmission);
    if (msg.data.stats) updateStatsDisplay(msg.data.stats);
    refreshMetrics();
    refreshTopology();
    if (msg.data.transmission.enforcement.incident_id) loadIncidents();
  } else if (msg.event === 'threat_armed') {
    setArmedThreatUI(msg.data.active_threat);
  } else if (msg.event === 'channel_state') {
    renderLinks(msg.data);
    refreshTopology();
  } else if (msg.event === 'security_event') {
    logTerminal('SEC', `${msg.data.type}: ${msg.data.detail}`);
  }
}

function initThreatCards() {
  const cards = document.querySelectorAll('.threat-card');
  cards.forEach(card => {
    card.addEventListener('click', async () => {
      const threatType = card.dataset.threat;
      setArmedThreatUI(threatType);
      try {
        await api('/api/arm-threat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ threat_type: threatType })
        }, 'admin');
        logTerminal('ARMED', `Injector set to scenario [${threatType.toUpperCase()}] (not visible to verifiers)`);
      } catch (err) {
        logTerminal('ERR', `Failed to arm: ${err.message}`);
      }
    });
  });
}

function setArmedThreatUI(threatType) {
  currentThreat = threatType;
  document.querySelectorAll('.threat-card').forEach(c => c.classList.toggle('active', c.dataset.threat === threatType));
  const tamperedGroup = document.getElementById('tamperedGroup');
  if (tamperedGroup) tamperedGroup.style.display = threatType === 'message_tampering' ? 'block' : 'none';
  const badge = document.getElementById('activeThreatBadge');
  if (badge) {
    badge.textContent = threatType.toUpperCase();
    badge.style.color = threatType === 'authentic' ? 'var(--cyan-glow)' : 'var(--crimson)';
    badge.style.borderColor = threatType === 'authentic' ? 'rgba(0, 242, 254, 0.4)' : 'rgba(244, 63, 94, 0.5)';
  }
}

function initComposer() {
  const form = document.getElementById('signForm');
  const bitSelect = document.getElementById('bitDepth');
  const previewBox = document.getElementById('tokenPreview');

  function renderPreview(n, symbols) {
    previewBox.innerHTML = '';
    const cls = { '|0⟩': 'token-z0', '|1⟩': 'token-z1', '|+⟩': 'token-x0', '|−⟩': 'token-x1' };
    for (let i = 0; i < n; i++) {
      const sym = symbols ? symbols[i] : '?';
      const span = document.createElement('span');
      span.className = `qubit-token ${cls[sym] || ''}`;
      span.textContent = `Q${i}: ${sym}`;
      previewBox.appendChild(span);
    }
  }
  window.renderTokenPreview = renderPreview;
  renderPreview(parseInt(bitSelect.value), null);
  bitSelect.addEventListener('change', () => renderPreview(parseInt(bitSelect.value), null));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btnSign');
    const tampered = document.getElementById('tamperedText');
    btn.disabled = true;
    btn.innerHTML = `<span class="title-icon">⏳</span> Teleporting & signing...`;
    try {
      const { status, data } = await api('/api/sign-and-send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message_text: document.getElementById('messageText').value,
          n_bits: parseInt(bitSelect.value),
          threat_type: currentThreat,
          tampered_text: tampered ? tampered.value : null
        })
      }, 'admin');
      if (status === 423) {
        logTerminal('BLOCK', `Refused in ${data.refusal_us} µs: link ${data.link} is quarantined ` +
          `(${data.detail.reason}; incident ${data.detail.incident_id}). Reset it with a reason to continue.`);
        refreshTopology();
      } else {
        data.transmissions.forEach(tx =>
          logTerminal('TX', `${tx.transmission_id} dispatched | ${tx.n_bits} qubits | injected: ${tx.ground_truth.injected_scenario}`));
        const last = data.transmission;
        if (last.alice) renderPreview(last.alice.state_symbols.length, last.alice.state_symbols);
      }
    } catch (err) {
      logTerminal('ERR', `Transmission failed: ${err.message}`);
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<span class="title-icon">⚡</span> Quantum Sign & Transmit Token`;
    }
  });
}

function verifierSummary(name, v) {
  if (!v) return `<span>${name}: —</span>`;
  const colour = v.is_valid ? 'var(--emerald)' : 'var(--crimson)';
  const mode = v.mode === 'forwarded' ? ` via ${escapeHtml(v.forwarded_by)}` : '';
  return `<span style="color:${colour}">${name}${mode}: ${v.is_valid ? 'ACCEPT' : 'REJECT'} ` +
         `${v.mismatches}/${v.total_checked}≤${v.acceptance_limit}</span>`;
}

function handleNewTransmission(tx) {
  if (seenTx.has(tx.transmission_id)) return;
  seenTx.add(tx.transmission_id);
  const container = document.getElementById('recentTxList');
  if (!container) return;
  if (seenTx.size === 1) container.innerHTML = '';

  const report = tx.threat_report;
  const injected = (tx.ground_truth && tx.ground_truth.injected_scenario) || 'unknown';
  const isThreat = report.is_threat_detected;
  const injectedAttack = injected !== 'authentic';
  const outcome = injectedAttack === isThreat
    ? (isThreat ? 'attack detected' : 'honest accepted')
    : (isThreat ? 'FALSE ALARM' : 'ATTACK MISSED');
  const channel = tx.channel
    ? `QBER^ ${(tx.channel.qber_estimate * 100).toFixed(1)}% (${tx.channel.error_count}/${tx.channel.test_count}, alarm >${tx.channel.alarm_threshold_errors}, p=${fmtP(tx.channel.p_value)})` +
      (tx.channel.early_abort ? ` · EARLY ABORT ${tx.channel.tokens_sent}/${tx.channel.tokens_planned} tokens` : '')
    : 'no channel test';
  const t2 = report.tier2 && report.tier2.applicable ? `Tier 2: ${report.tier2.attribution}` : '';
  const resp = tx.response ? `${tx.response.response_action} (p=${fmtP(tx.response.evidence_p)})` : tx.enforcement.action;
  const incident = tx.enforcement.incident_id
    ? `<a href="/api/audit/${encodeURIComponent(tx.enforcement.incident_id)}" target="_blank" style="color:var(--crimson)">incident ${escapeHtml(tx.enforcement.incident_id)} ⬇</a>` : '';

  const row = document.createElement('div');
  row.className = 'glass-panel';
  row.style.padding = '0.85rem';
  row.style.marginBottom = '0.75rem';
  row.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.4rem; gap:0.5rem;">
      <span style="font-family:var(--font-mono); font-weight:700; color:var(--cyan-glow);">${escapeHtml(tx.transmission_id)}</span>
      <span style="font-size:0.75rem; font-family:var(--font-mono); color:${isThreat ? 'var(--crimson)' : 'var(--emerald)'}">
        ${escapeHtml(report.classification)}</span>
    </div>
    <div style="font-size:0.85rem; margin-bottom:0.4rem; color:var(--text-main);">"${escapeHtml(tx.message_text)}"</div>
    <div style="display:flex; flex-wrap:wrap; gap:0.4rem 1rem; font-size:0.75rem; font-family:var(--font-mono); color:var(--text-dim);">
      ${verifierSummary('Bob', tx.bob)}
      ${verifierSummary('Charlie', tx.charlie)}
      <span>${channel}</span>
    </div>
    <div style="display:flex; flex-wrap:wrap; gap:0.4rem 1rem; font-size:0.75rem; font-family:var(--font-mono); margin-top:0.35rem;">
      <span style="color:var(--text-dim)">injected: <strong>${escapeHtml(injected)}</strong></span>
      <span style="color:${outcome === outcome.toUpperCase() ? 'var(--amber)' : 'var(--text-dim)'}">${outcome}</span>
      <span style="color:var(--text-dim)">${escapeHtml(tx.enforcement.action)} → ${escapeHtml(resp)}</span>
      ${t2 ? `<span style="color:var(--text-dim)">${escapeHtml(t2)}</span>` : ''}
      <a href="/api/audit/${encodeURIComponent(tx.transmission_id)}" target="_blank" style="color:var(--cyan-glow)">audit ⬇</a>
      ${incident}
    </div>`;
  container.prepend(row);
  logTerminal('RECV', `${tx.transmission_id}: ${report.verdict}`);
  renderLinks(tx.enforcement.channel_state);
}

function renderLinks(channelState) {
  if (!channelState) return;
  renderChannelBanner(channelState);
  const el = document.getElementById('linkStates');
  if (!el) return;
  el.innerHTML = Object.entries(channelState).map(([link, s]) =>
    `<span class="link-chip ${s.state}">${escapeHtml(link)}: ${s.state.replace('_', ' ').toUpperCase()}` +
    `${s.strikes ? ` · strikes ${s.strikes}` : ''}${s.refused ? ` · refused ${s.refused}` : ''}</span>`).join('');
}

async function resetLinks() {
  const reason = window.prompt('Reason for resetting the quarantined / watched links (kept in the signed audit chain):');
  if (!reason || reason.trim().length < 3) {
    logTerminal('ERR', 'Reset cancelled: a reason of at least 3 characters is required.');
    return;
  }
  try {
    const { data } = await api('/api/channel/reset', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reason: reason.trim() })
    }, 'admin');
    renderLinks(data.channel_state);
    refreshTopology();
    const n = (data.transitions || []).length;
    logTerminal('SYS', n
      ? `${n} link(s) reset by admin ("${reason.trim()}"): quarantined → probation, watch → open. Signed reset record #${data.reset_record.chain_seq}.`
      : 'No link needed a reset.');
  } catch (err) {
    logTerminal('ERR', `Reset failed: ${err.message}`);
  }
}

const HOP_COLOURS = { up: 'var(--emerald)', degraded: 'var(--amber)', probation: 'var(--cyan-glow)', down: 'var(--crimson)' };

async function refreshTopology() {
  try {
    const { data } = await api('/api/topology', {}, 'admin');
    renderTopology(data.router);
  } catch (e) { /* informational */ }
}

function renderTopology(router) {
  const svg = document.getElementById('topologySvg');
  if (!svg || !router) return;
  const pos = { alice: [40, 60], 'QR-1': [190, 60], bob: [360, 25], charlie: [360, 135] };
  const hops = router.hops;
  const line = (name, a, b, bend) => {
    const h = hops[name];
    const c = HOP_COLOURS[h.state] || 'var(--text-dim)';
    const [x1, y1] = pos[a], [x2, y2] = pos[b];
    const mx = (x1 + x2) / 2 + (bend || 0), my = (y1 + y2) / 2;
    const path = bend ? `M${x1},${y1} Q${mx},${my} ${x2},${y2}` : `M${x1},${y1} L${x2},${y2}`;
    const dash = h.kind === 'classical' ? ' stroke-dasharray="5 4"' : '';
    return `<path d="${path}" fill="none" stroke="${c}" stroke-width="${h.state === 'down' ? 3 : 2}"${dash}/>` +
      `<text class="hop-label" x="${mx - 30}" y="${my - 5}">${escapeHtml(h.state)} · ${h.tokens_carried} tok${h.dropped ? ` · ${h.dropped} dropped` : ''}</text>`;
  };
  const node = (name, label) => {
    const [x, y] = pos[name];
    return `<circle cx="${x}" cy="${y}" r="15" fill="var(--bg-panel, #0b1220)" stroke="var(--cyan-glow)" stroke-width="1.5"/>` +
      `<text x="${x}" y="${y + 3.5}" text-anchor="middle">${label}</text>`;
  };
  svg.innerHTML =
    line('alice->QR-1', 'alice', 'QR-1') + line('QR-1->bob', 'QR-1', 'bob') + line('QR-1->charlie', 'QR-1', 'charlie') +
    line('bob->charlie', 'bob', 'charlie', 60) +
    node('alice', 'A') + node('QR-1', 'QR') + node('bob', 'B') + node('charlie', 'C');
}

async function loadIncidents() {
  try {
    const { data } = await api('/api/incidents', {}, 'admin');
    const el = document.getElementById('incidentList');
    if (!el) return;
    const items = (data.incidents || []).slice(-6).reverse();
    el.innerHTML = items.length ? items.map(c => {
      const r = c.record;
      return `<div class="incident-item">${escapeHtml(r.incident_id)} · ${escapeHtml(r.link)} · ` +
        `${escapeHtml(r.trigger.classification)} (p=${fmtP(r.trigger.evidence_p)}) · ` +
        `${new Date(r.issued_at * 1000).toLocaleTimeString()} · chain #${r.chain.seq} ` +
        `<a href="/api/audit/${encodeURIComponent(r.incident_id)}" target="_blank">⬇</a></div>`;
    }).join('') : '<div class="truth-row">No incidents.</div>';
  } catch (e) { /* informational */ }
}

async function checkChain() {
  try {
    const { data } = await api('/api/audit/chain', {}, 'admin');
    const v = data.verification;
    const pq = (data.certificates || []).some(c => (c.signatures || []).some(s => s.post_quantum));
    document.getElementById('chainRow').textContent =
      `Chain: ${v.length} signed artifact(s) · ${v.valid ? 'ALL SIGNATURES AND HASH LINKS VALID' : `${v.problems.length} PROBLEM(S)`}` +
      ` · ${pq ? 'hybrid Ed25519 + ML-DSA-65' : 'Ed25519 (classical)'}`;
    logTerminal(v.valid ? 'SYS' : 'ERR', `Audit chain check: ${v.valid ? 'valid' : JSON.stringify(v.problems.slice(0, 3))}`);
  } catch (err) {
    logTerminal('ERR', `Chain check failed: ${err.message}`);
  }
}

function updateStatsDisplay(stats) {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('statTotal', stats.total_sent);
  set('statAuth', stats.verified_authentic);
  set('statThreat', stats.threats_detected);
  set('statQber', `${(stats.last_qber * 100).toFixed(1)}%`);
  set('statTruth', `Injected attacks: ${stats.attacks_injected} · missed: ${stats.attacks_missed} · false alarms: ${stats.false_alarms}` +
    ` · watch: ${stats.watch_events ?? 0} · quarantines: ${stats.quarantines ?? 0} · early aborts: ${stats.early_aborts ?? 0} · refused: ${stats.refused_sends ?? 0}`);
}

async function refreshMetrics() {
  try {
    const { data } = await api('/api/metrics', {}, 'admin');
    const l = data.latency;
    const fmt = s => s && s.count ? `p50 ${s.p50} / p95 ${s.p95}` : '—';
    document.getElementById('latencyRow').textContent =
      `Latency (${data.backend}; n=${l.detection_us.count || 0}) — channel observation ms ${fmt(l.channel_observation_ms)} · ` +
      `detection µs ${fmt(l.detection_us)} · post-verdict enforcement µs ${fmt(l.enforcement_us)} · ` +
      `incident signing µs ${fmt(l.incident_signing_us)} · 423 refusal µs ${fmt(l.refusal_us)} · full run ms ${fmt(l.protocol_ms)}`;
  } catch (e) { /* metrics are informational */ }
}

async function loadHistory() {
  try {
    const { data } = await api('/api/history', {}, 'admin');
    if (data.stats) updateStatsDisplay(data.stats);
    renderLinks(data.channel_state);
    (data.transmissions || []).slice(-5).forEach(tx => handleNewTransmission(tx));
  } catch (e) {
    console.error('History load error:', e);
  }
}

function logTerminal(prefix, msg) {
  const term = document.getElementById('terminalLog');
  if (!term) return;
  const line = document.createElement('div');
  line.className = 'log-entry';
  let cls = '';
  if (['ARMED', 'ERR', 'SEC', 'BLOCK'].includes(prefix)) cls = 'log-threat';
  if (prefix === 'TX' || prefix === 'RECV') cls = 'log-success';
  line.innerHTML = `<span class="log-ts">[${new Date().toLocaleTimeString()}]</span> ` +
                   `<span class="log-prefix">${prefix}</span> <span class="${cls}">${escapeHtml(msg)}</span>`;
  term.appendChild(line);
  term.scrollTop = term.scrollHeight;
}
